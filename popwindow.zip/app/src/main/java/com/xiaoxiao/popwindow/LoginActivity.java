package com.xiaoxiao.popwindow;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

public class LoginActivity extends FragmentActivity {
	private MyPopupwindow myPopupWindow;
	private HonestClickListener mHonestClickListener;
	private RelativeLayout root;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		root = (RelativeLayout) findViewById(R.id.root);
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		popupWindow();
	}

	public void popupWindow(){
		//弹出pop
//点击时弹出PopupWindow，屏幕变暗
		LayoutInflater.from(this);

		mHonestClickListener = new HonestClickListener();
		myPopupWindow = new MyPopupwindow(this, mHonestClickListener,root.getHeight());
		myPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
			@Override
			public void onDismiss() {
				lighton();
			}
		});
		myPopupWindow.setOutsideTouchable(true);
		myPopupWindow.setBackgroundDrawable(new BitmapDrawable());
		myPopupWindow.setAnimationStyle(R.style.popwin_anim_style);
		myPopupWindow.showAtLocation(View.inflate(this,R.layout.activity_main,null), Gravity.CENTER,
				0, 100);
		lightoff();
		new Handler(new Handler.Callback() {
			@Override
			public boolean handleMessage(Message msg) {
				lighton();
				return false;
			}
		}).sendEmptyMessageDelayed(0,500);
	}
	/**
	 * @date 2017/3/21
	 * @desc 当popupWindow弹出是背景变暗
	 */
	private void lightoff() {
		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.alpha = 0.3f;
		getWindow().setAttributes(lp);
	}

	/**
	 * @date 2017/3/22
	 * @desc PopupWindow消失时，使屏幕恢复正常
	 */
	private void lighton() {
		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.alpha = 1.0f;
		getWindow().setAttributes(lp);
	}

	public class HonestClickListener implements View.OnClickListener {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
				case R.id.ll_agree://同意进入首页
					myPopupWindow.dismiss();
					Intent intent = new Intent(LoginActivity.this, MainActivity.class);
					startActivity(intent);
					finish();
					break;
				case R.id.ll_return://关闭popwindow消失
					myPopupWindow.dismiss();
					break;
			}
		}
	}
}
